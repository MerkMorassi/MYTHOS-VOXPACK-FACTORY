import React, { useEffect, useState } from 'react';
import { LorepackFactory } from '../lorepack-factory.ts';
import { IndexedDbLorepackStore } from '../indexeddb-store.ts';
import { GeminiProvider } from '../providers/gemini-provider.ts';
import { Database, Zap, Activity, Send, Download, Layers, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';

interface EngineeringConsoleProps {
  factory: LorepackFactory | null;
  store: IndexedDbLorepackStore | null;
  provider: GeminiProvider | null;
  log?: (msg: string) => void;
}

/**
 * MYTHOS LOREPACK FACTORY - ENGINEERING CONSOLE
 * 
 * This is a streamlined interface for the Lorepack Factory core.
 * Focuses on system status, metrics, and basic API entry points.
 */
export const EngineeringConsole: React.FC<EngineeringConsoleProps> = ({
  factory,
  store,
  provider,
  log: parentLog
}) => {
  // System State
  const [apiStatus, setApiStatus] = useState<'IDLE' | 'ONLINE' | 'ERROR'>('IDLE');
  const [stats, setStats] = useState({ nodes: 0, edges: 0 });
  
  // Interaction State
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [localLogs, setLocalLogs] = useState<{msg: string, type: 'info' | 'ok' | 'err'}[]>([]);

  const addLog = (msg: string, type: 'info' | 'ok' | 'err' = 'info') => {
    setLocalLogs(prev => [{ msg, type }, ...prev].slice(0, 10));
    if (parentLog) parentLog(`[ENGINEER]: ${msg}`);
  };

  useEffect(() => {
    async function checkHealth() {
      if (!factory) return;
      
      try {
        const res = await fetch('/api/health');
        if (res.ok) {
          setApiStatus('ONLINE');
          addLog('Gemini API bridge verified.', 'ok');
        } else {
          setApiStatus('ERROR');
          addLog('Gemini API bridge offline.', 'err');
        }
      } catch {
        setApiStatus('ERROR');
        addLog('Gemini API bridge connection refused.', 'err');
      }

      const s = await factory.getStats('CORE_AGENT');
      setStats({ nodes: s.totalNodes, edges: s.totalEdges });
    }
    
    checkHealth();
  }, [factory]);

  const refreshStats = async () => {
    if (factory) {
      const s = await factory.getStats('CORE_AGENT');
      setStats({ nodes: s.totalNodes, edges: s.totalEdges });
    }
  };

  const handleIngestSample = async () => {
    if (!factory || isProcessing) return;
    setIsProcessing(true);
    addLog('Synthesizing sample lore...', 'info');
    try {
      const sampleText = "The MythOS Lorepack Factory serves as the primary engineering locus for Zoe Films memory distribution. It utilizes relational vector embeddings to preserve semantic cohesion across distributed port channels.";
      const chunks = factory.chunk(sampleText, 500);
      const batches = chunks.map(t => ({ text: t, source: 'engineer-console-sample' }));
      
      const result = await factory.ingestBatches(batches, {
        agentId: 'CORE_AGENT',
      });
      
      addLog(`Committed ${result.ingested} vector records to vault.`, 'ok');
      await refreshStats();
    } catch (err: any) {
      addLog(`Ingest Failed: ${err.message}`, 'err');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSearch = async () => {
    if (!factory || !query.trim() || isProcessing) return;
    setIsProcessing(true);
    addLog(`Searching vault: "${query}"`, 'info');
    try {
      const results = await factory.reader.search(query, 'CORE_AGENT', 3);
      if (results.length > 0) {
        setResponse(`RETRIEVAL SUCCESS:\n\n${results.map((r, i) => `[${i+1}] (Score: ${r.score.toFixed(4)})\n${r.node.text}`).join('\n\n')}`);
        addLog('Found matches in local vault.', 'ok');
      } else {
        setResponse('ZERO_MATCH: No relevant contextual memories found in agent vault.');
        addLog('No matches found.', 'info');
      }
    } catch (err: any) {
      setResponse(`ERROR: ${err.message}`);
      addLog('Search error.', 'err');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExport = async () => {
    if (!factory || isProcessing) return;
    setIsProcessing(true);
    addLog('Compiling Lorepack archive...', 'info');
    try {
      const { blob, filename, count } = await factory.exportToGz('CORE_AGENT');
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      addLog(`Exported ${count} records to ${filename}.`, 'ok');
    } catch (err: any) {
      addLog(`Export Failed: ${err.message}`, 'err');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col font-mono text-[#e0e0e0] bg-[#080808] selection:bg-[#00ff41] selection:text-black overflow-hidden rounded-lg border border-[#222]">
      {/* Header */}
      <div className="border-b border-[#222] bg-[#0c0c0c] px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#151515] border border-[#2a2a2a] rounded-sm">
            <Layers className="w-5 h-5 text-[#00ff41]" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight text-white uppercase">Engineers Console</h1>
            <p className="text-[10px] text-[#666] uppercase tracking-widest font-semibold">Engineering Interface // CORE_AGENT</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#111] border border-[#222] rounded-sm">
            <div className={`w-1.5 h-1.5 rounded-full ${apiStatus === 'ONLINE' ? 'bg-[#00ff41] animate-pulse' : 'bg-red-500'}`} />
            <span className="text-[10px] uppercase font-bold text-[#888]">API BRIDGE</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#111] border border-[#222] rounded-sm">
            <div className={`w-1.5 h-1.5 rounded-full ${factory ? 'bg-[#00ff41]' : 'bg-red-500'}`} />
            <span className="text-[10px] uppercase font-bold text-[#888]">KERNEL</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: System Control & Metrics */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <section className="bg-[#0c0c0c] border border-[#222] p-5 rounded-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 p-3 opacity-10">
              <Activity className="w-12 h-12" />
            </div>
            <h2 className="text-[11px] font-bold text-[#00ff41] uppercase tracking-widest mb-4 border-b border-[#222] pb-2">Locus Metrics</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#111] p-3 border border-[#1a1a1a]">
                <p className="text-[9px] text-[#666] uppercase font-bold">Vector Nodes</p>
                <p className="text-xl font-bold text-white mt-1">{stats.nodes}</p>
              </div>
              <div className="bg-[#111] p-3 border border-[#1a1a1a]">
                <p className="text-[9px] text-[#666] uppercase font-bold">Relational Edges</p>
                <p className="text-xl font-bold text-white mt-1">{stats.edges}</p>
              </div>
            </div>
          </section>

          <section className="bg-[#0c0c0c] border border-[#222] p-5 rounded-sm">
            <h2 className="text-[11px] font-bold text-[#00ff41] uppercase tracking-widest mb-4 border-b border-[#222] pb-2">Core Operations</h2>
            <div className="flex flex-col gap-3">
              <button
                onClick={handleIngestSample}
                disabled={isProcessing || !factory}
                className="group flex items-center justify-between w-full bg-[#111] border border-[#222] hover:border-[#00ff41] p-3 transition-all disabled:opacity-40 disabled:hover:border-[#222] cursor-pointer"
              >
                <div className="text-left">
                  <p className="text-[10px] font-bold text-white uppercase">Synthesize Sample</p>
                  <p className="text-[9px] text-[#666]">Commit default lore to vault</p>
                </div>
                <Zap className="w-4 h-4 text-[#444] group-hover:text-[#00ff41]" />
              </button>
              
              <button
                onClick={handleExport}
                disabled={isProcessing || stats.nodes === 0 || !factory}
                className="group flex items-center justify-between w-full bg-[#111] border border-[#222] hover:border-[#00ff41] p-3 transition-all disabled:opacity-40 disabled:hover:border-[#222] cursor-pointer"
              >
                <div className="text-left">
                  <p className="text-[10px] font-bold text-white uppercase">Compile Lorepack</p>
                  <p className="text-[9px] text-[#666]">Export GZIP compressed memory</p>
                </div>
                <Download className="w-4 h-4 text-[#444] group-hover:text-[#00ff41]" />
              </button>
            </div>
          </section>

          {/* Activity Log */}
          <section className="bg-[#0c0c0c] border border-[#222] p-5 rounded-sm flex-1 min-h-[200px]">
            <h2 className="text-[11px] font-bold text-[#00ff41] uppercase tracking-widest mb-4 border-b border-[#222] pb-2">Console Events</h2>
            <div className="space-y-3">
              {localLogs.map((log, i) => (
                <div key={i} className="flex gap-2 text-[10px] leading-tight">
                  <span className="text-[#444] shrink-0">[{new Date().toLocaleTimeString([], { hour12: false })}]</span>
                  <div className="flex items-start gap-1.5">
                    {log.type === 'ok' && <CheckCircle2 className="w-2.5 h-2.5 text-[#00ff41] shrink-0 mt-0.5" />}
                    {log.type === 'err' && <AlertCircle className="w-2.5 h-2.5 text-red-500 shrink-0 mt-0.5" />}
                    <span className={log.type === 'err' ? 'text-red-400' : log.type === 'ok' ? 'text-[#00ff41]' : 'text-[#888]'}>
                      {log.msg}
                    </span>
                  </div>
                </div>
              ))}
              {localLogs.length === 0 && <p className="text-[10px] text-[#444] italic">Listening for system events...</p>}
            </div>
          </section>
        </div>

        {/* Right: Interaction Interface */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          <section className="bg-[#0c0c0c] border border-[#222] p-6 rounded-sm flex flex-col min-h-[500px]">
            <div className="flex items-center gap-3 mb-8 border-b border-[#222] pb-4">
              <Database className="w-5 h-5 text-[#00ff41]" />
              <div>
                <h2 className="text-xs font-bold text-white uppercase tracking-wider">Semantic Retrieval Engine</h2>
                <p className="text-[10px] text-[#666] uppercase">Query local vector memory in real-time</p>
              </div>
            </div>

            <div className="flex gap-2 mb-6">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  placeholder="Execute semantic search query..."
                  className="w-full bg-[#111] border border-[#222] px-4 py-3 text-xs text-white focus:outline-none focus:border-[#00ff41] transition-colors pl-10"
                />
                <Send className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#444]" />
              </div>
              <button
                onClick={handleSearch}
                disabled={isProcessing || !query.trim() || !factory}
                className="bg-[#00ff41] text-black px-6 py-3 font-bold text-xs uppercase tracking-widest hover:bg-[#00cc33] transition-all disabled:opacity-30 disabled:hover:bg-[#00ff41] rounded-sm cursor-pointer"
              >
                Execute
              </button>
            </div>

            <div className="flex-1 bg-[#050505] border border-[#1a1a1a] rounded-sm p-6 overflow-y-auto">
              {response ? (
                <div className="whitespace-pre-wrap text-xs font-mono leading-relaxed text-[#00ff41]">
                  <span className="text-[#666] block mb-4 uppercase text-[10px] border-b border-[#1a1a1a] pb-1">Retrieval Output Payload:</span>
                  {response}
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center opacity-20 grayscale">
                  <ShieldCheck className="w-16 h-16 mb-4" />
                  <p className="text-[10px] uppercase font-bold tracking-widest">Awaiting Semantic Probe</p>
                </div>
              )}
            </div>
            
            {isProcessing && (
              <div className="mt-4 flex items-center gap-2 justify-center">
                <div className="w-2 h-2 bg-[#00ff41] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-[#00ff41] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-[#00ff41] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                <span className="text-[10px] uppercase text-[#00ff41] font-bold ml-2">Kernel Processing...</span>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};
