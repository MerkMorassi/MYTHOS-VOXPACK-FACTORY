import type { LorepackStore, StoredLorepackArchive, TripletEdge, VectorRecord } from './types.js';

const VECTOR_STORE = 'vectors';
const EDGE_STORE = 'edges';

export class IndexedDbLorepackStore implements LorepackStore {
  private database: IDBDatabase | null = null;

  constructor(
    private readonly databaseName = 'mythos_vault',
    private readonly databaseVersion = 11,
  ) {}

  async addVectors(vectors: VectorRecord[]): Promise<void> {
    const validVectors = vectors
      .filter((vector) => Array.isArray(vector.vector))
      .map((vector) => ({
        ...vector,
        processing_status: vector.processing_status || 'pending',
      }));
    await this.writeMany(VECTOR_STORE, validVectors);
  }

  async getVectorsByAgent(agentId: string): Promise<VectorRecord[]> {
    return this.readByAgent<VectorRecord>(VECTOR_STORE, agentId);
  }

  async getAllVectors(): Promise<VectorRecord[]> {
    return this.readAll<VectorRecord>(VECTOR_STORE);
  }

  async getUnprocessedVectorsByAgent(agentId: string): Promise<VectorRecord[]> {
    const allForAgent = await this.getVectorsByAgent(agentId);
    return allForAgent.filter((v) => v.processing_status !== 'completed');
  }

  async updateVectorProcessingStatus(
    ids: string[],
    status: 'pending' | 'processing' | 'completed' | 'error'
  ): Promise<void> {
    if (ids.length === 0) return;
    const database = await this.open();
    const idSet = new Set(ids);
    return new Promise<void>((resolve, reject) => {
      const transaction = database.transaction(VECTOR_STORE, 'readwrite');
      const store = transaction.objectStore(VECTOR_STORE);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);

      for (const id of idSet) {
        const getReq = store.get(id);
        getReq.onsuccess = () => {
          const record = getReq.result as VectorRecord | undefined;
          if (record) {
            record.processing_status = status;
            store.put(record);
          }
        };
      }
    });
  }

  async addTripletEdges(edges: TripletEdge[]): Promise<void> {
    await this.writeMany(EDGE_STORE, edges);
  }

  async deleteTripletEdges(ids: string[]): Promise<void> {
    if (ids.length === 0) return;
    const database = await this.open();
    return new Promise<void>((resolve, reject) => {
      const transaction = database.transaction(EDGE_STORE, 'readwrite');
      const store = transaction.objectStore(EDGE_STORE);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      for (const id of ids) {
        store.delete(id);
      }
    });
  }

  async getTripletEdgesByAgent(agentId: string): Promise<TripletEdge[]> {
    return this.readByAgent<TripletEdge>(EDGE_STORE, agentId.toUpperCase());
  }

  async getAllTripletEdges(): Promise<TripletEdge[]> {
    return this.readAll<TripletEdge>(EDGE_STORE);
  }

  private async open(): Promise<IDBDatabase> {
    if (this.database) return this.database;

    this.database = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open(this.databaseName, this.databaseVersion);
      request.onupgradeneeded = (e: any) => {
        const database = request.result;
        const tx = request.transaction;

        if (!database.objectStoreNames.contains(VECTOR_STORE)) {
          const store = database.createObjectStore(VECTOR_STORE, { keyPath: 'id' });
          store.createIndex('agentId', 'agentId', { unique: false });
          store.createIndex('numMarkId', 'numMarkId', { unique: false });
          store.createIndex('processing_status', 'processing_status', { unique: false });
        } else if (tx) {
          const store = tx.objectStore(VECTOR_STORE);
          if (!store.indexNames.contains('agentId')) {
            store.createIndex('agentId', 'agentId', { unique: false });
          }
          if (!store.indexNames.contains('numMarkId')) {
            store.createIndex('numMarkId', 'numMarkId', { unique: false });
          }
          if (!store.indexNames.contains('processing_status')) {
            store.createIndex('processing_status', 'processing_status', { unique: false });
          }
        }

        if (!database.objectStoreNames.contains(EDGE_STORE)) {
          const store = database.createObjectStore(EDGE_STORE, { keyPath: 'id' });
          store.createIndex('agentId', 'agentId', { unique: false });
          store.createIndex('sourceId', 'sourceId', { unique: false });
          store.createIndex('type', 'type', { unique: false });
        } else if (tx) {
          const store = tx.objectStore(EDGE_STORE);
          if (!store.indexNames.contains('agentId')) {
            store.createIndex('agentId', 'agentId', { unique: false });
          }
          if (!store.indexNames.contains('sourceId')) {
            store.createIndex('sourceId', 'sourceId', { unique: false });
          }
          if (!store.indexNames.contains('type')) {
            store.createIndex('type', 'type', { unique: false });
          }
        }
      };
      request.onsuccess = () => {
        const db = request.result;
        db.onversionchange = () => {
          try {
            db.close();
          } catch (_) {}
          this.database = null;
        };
        resolve(db);
      };
      request.onerror = () => reject(request.error);
    });

    return this.database;
  }

  private async writeMany<T>(storeName: string, records: T[]): Promise<void> {
    if (records.length === 0) return;
    const database = await this.open();
    await new Promise<void>((resolve, reject) => {
      const transaction = database.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      records.forEach((record) => store.put(record));
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  private async readAll<T>(storeName: string): Promise<T[]> {
    const database = await this.open();
    return new Promise<T[]>((resolve, reject) => {
      const request = database.transaction(storeName, 'readonly').objectStore(storeName).getAll();
      request.onsuccess = () => resolve(request.result as T[]);
      request.onerror = () => reject(request.error);
    });
  }

  private async readByAgent<T>(storeName: string, agentId: string): Promise<T[]> {
    const database = await this.open();
    return new Promise<T[]>((resolve, reject) => {
      const request = database
        .transaction(storeName, 'readonly')
        .objectStore(storeName)
        .index('agentId')
        .getAll(agentId);
      request.onsuccess = () => resolve(request.result as T[]);
      request.onerror = () => reject(request.error);
    });
  }

  async addRecordsAtomic(vectors: VectorRecord[], edges: TripletEdge[]): Promise<void> {
    const database = await this.open();
    return new Promise<void>((resolve, reject) => {
      const transaction = database.transaction([VECTOR_STORE, EDGE_STORE], 'readwrite');
      const vectorStore = transaction.objectStore(VECTOR_STORE);
      const edgeStore = transaction.objectStore(EDGE_STORE);

      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error || new Error('Atomic IndexedDB write failed.'));
      transaction.onabort = () => reject(transaction.error || new Error('Atomic IndexedDB write aborted.'));

      for (const vector of vectors) {
        if (Array.isArray(vector.vector)) {
          vectorStore.put({
            ...vector,
            processing_status: vector.processing_status || 'pending',
          });
        }
      }

      for (const edge of edges) {
        edgeStore.put(edge);
      }
    });
  }

  async clearAgent(agentId: string): Promise<{ vectors: number; edges: number }> {
    // 1. Normalize/validate the agent ID
    if (!agentId || typeof agentId !== 'string' || !agentId.trim()) {
      throw new Error('Invalid agent ID: agent ID must be a non-empty string.');
    }
    const normalizedAgentId = agentId.trim();
    const targetAgentIds = Array.from(new Set([
      normalizedAgentId,
      normalizedAgentId.toUpperCase(),
      normalizedAgentId.toLowerCase(),
    ]));

    // 2. Open mythos_vault using the current schema/version
    const database = await this.open();

    // 3. Start ONE readwrite transaction covering BOTH vectors and edges
    return new Promise<{ vectors: number; edges: number }>((resolve, reject) => {
      let transaction: IDBTransaction;
      try {
        transaction = database.transaction([VECTOR_STORE, EDGE_STORE], 'readwrite');
      } catch (err) {
        return reject(err);
      }

      const vectorStore = transaction.objectStore(VECTOR_STORE);
      const edgeStore = transaction.objectStore(EDGE_STORE);

      let deletedVectors = 0;
      let deletedEdges = 0;
      const seenVectorIds = new Set<string>();
      const seenEdgeIds = new Set<string>();

      // 6. Commit atomically & 8. Return useful summary
      transaction.oncomplete = () => {
        resolve({ vectors: deletedVectors, edges: deletedEdges });
      };

      // 7. Reject on transaction error/abort
      transaction.onerror = () => {
        reject(transaction.error || new Error('Clear agent transaction failed.'));
      };
      transaction.onabort = () => {
        reject(transaction.error || new Error('Clear agent transaction aborted.'));
      };

      // 4. Delete every vector belonging to that agent
      const vIndex = vectorStore.index('agentId');
      for (const target of targetAgentIds) {
        const vReq = vIndex.openCursor(target);
        vReq.onsuccess = (event: any) => {
          const cursor = event.target.result;
          if (cursor) {
            const val = cursor.value;
            const primaryKey = cursor.primaryKey || (val && val.id);
            if (primaryKey && !seenVectorIds.has(String(primaryKey))) {
              seenVectorIds.add(String(primaryKey));
              deletedVectors++;
              cursor.delete();
            }
            cursor.continue();
          }
        };
      }

      // 5. Delete every relationship edge belonging to that agent
      const eIndex = edgeStore.index('agentId');
      for (const target of targetAgentIds) {
        const eReq = eIndex.openCursor(target);
        eReq.onsuccess = (event: any) => {
          const cursor = event.target.result;
          if (cursor) {
            const val = cursor.value;
            const primaryKey = cursor.primaryKey || (val && val.id);
            if (primaryKey && !seenEdgeIds.has(String(primaryKey))) {
              seenEdgeIds.add(String(primaryKey));
              deletedEdges++;
              cursor.delete();
            }
            cursor.continue();
          }
        };
      }
    });
  }

  async nukeStore(): Promise<void> {
    // 1. Wipe stores directly if connection is open
    try {
      if (this.database) {
        const db = this.database;
        const storeNames = Array.from(db.objectStoreNames);
        if (storeNames.length > 0) {
          await new Promise<void>((res) => {
            try {
              const tx = db.transaction(storeNames, 'readwrite');
              storeNames.forEach((s) => {
                try {
                  tx.objectStore(s).clear();
                } catch (_) {}
              });
              tx.oncomplete = () => res();
              tx.onerror = () => res();
              tx.onabort = () => res();
            } catch (_) {
              res();
            }
          });
        }
      }
    } catch (_) {}

    // 2. Explicitly close active database connection
    if (this.database) {
      try {
        this.database.close();
      } catch (_) {}
      this.database = null;
    }

    // 3. Delete database file
    return new Promise<void>((resolve, reject) => {
      let resolved = false;
      const request = indexedDB.deleteDatabase(this.databaseName);
      
      request.onsuccess = () => {
        this.database = null;
        if (!resolved) {
          resolved = true;
          resolve();
        }
      };
      
      request.onerror = () => {
        this.database = null;
        if (!resolved) {
          resolved = true;
          resolve();
        }
      };

      request.onblocked = () => {
        if (this.database) {
          try {
            this.database.close();
          } catch (_) {}
          this.database = null;
        }
        setTimeout(() => {
          if (!resolved) {
            resolved = true;
            resolve();
          }
        }, 100);
      };

      // Failsafe timeout
      setTimeout(() => {
        if (!resolved) {
          resolved = true;
          this.database = null;
          resolve();
        }
      }, 800);
    });
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    let dotProduct = 0;
    let magnitudeA = 0;
    let magnitudeB = 0;
    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      magnitudeA += a[i] * a[i];
      magnitudeB += b[i] * b[i];
    }
    magnitudeA = Math.sqrt(magnitudeA);
    magnitudeB = Math.sqrt(magnitudeB);
    if (magnitudeA === 0 || magnitudeB === 0) return 0;
    return dotProduct / (magnitudeA * magnitudeB);
  }

  async searchVectorsBySimilarity(queryVector: number[], limit: number): Promise<VectorRecord[]> {
    const allVectors = await this.getAllVectors();
    return allVectors
      .map(v => ({
        vector: v,
        similarity: this.cosineSimilarity(queryVector, v.vector)
      }))
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit)
      .map(v => v.vector);
  }
}

/**
 * Isolated Archive Store for persisting completed Lorepack GZIP archives.
 * Persists raw Blobs natively into IndexedDB without affecting the primary
 * vector/edge database schemas.
 */
export class IndexedDbArchiveStore {
  private database: IDBDatabase | null = null;
  private readonly dbName = 'mythos_archive_vault';
  private readonly dbVersion = 1;
  private readonly storeName = 'archives';

  private async open(): Promise<IDBDatabase> {
    if (this.database) return this.database;

    return new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);

      request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
        const db = request.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          const store = db.createObjectStore(this.storeName, { keyPath: 'id' });
          store.createIndex('agentId', 'agentId', { unique: false });
          store.createIndex('createdAt', 'createdAt', { unique: false });
        }
      };

      request.onsuccess = () => {
        this.database = request.result;
        this.database.onversionchange = () => {
          try {
            this.database?.close();
          } catch (_) {}
          this.database = null;
        };
        resolve(this.database);
      };

      request.onerror = () => reject(request.error);
    });
  }

  async saveArchive(archive: StoredLorepackArchive): Promise<void> {
    const db = await this.open();
    return new Promise<void>((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readwrite');
      const store = tx.objectStore(this.storeName);
      store.put(archive);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async getAllArchives(): Promise<StoredLorepackArchive[]> {
    const db = await this.open();
    return new Promise<StoredLorepackArchive[]>((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readonly');
      const store = tx.objectStore(this.storeName);
      const req = store.getAll();
      req.onsuccess = () => {
        const res = (req.result as StoredLorepackArchive[]) || [];
        res.sort((a, b) => b.createdAt - a.createdAt);
        resolve(res);
      };
      req.onerror = () => reject(req.error);
    });
  }

  async getArchivesByAgent(agentId: string): Promise<StoredLorepackArchive[]> {
    const all = await this.getAllArchives();
    return all.filter((a) => a.agentId.toLowerCase() === agentId.toLowerCase());
  }

  async getArchiveById(id: string): Promise<StoredLorepackArchive | null> {
    const db = await this.open();
    return new Promise<StoredLorepackArchive | null>((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readonly');
      const store = tx.objectStore(this.storeName);
      const req = store.get(id);
      req.onsuccess = () => resolve((req.result as StoredLorepackArchive) || null);
      req.onerror = () => reject(req.error);
    });
  }

  async deleteArchive(id: string): Promise<void> {
    const db = await this.open();
    return new Promise<void>((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readwrite');
      const store = tx.objectStore(this.storeName);
      store.delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async clearArchives(): Promise<void> {
    const db = await this.open();
    return new Promise<void>((resolve, reject) => {
      const tx = db.transaction(this.storeName, 'readwrite');
      const store = tx.objectStore(this.storeName);
      store.clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}

export const archiveStore = new IndexedDbArchiveStore();

