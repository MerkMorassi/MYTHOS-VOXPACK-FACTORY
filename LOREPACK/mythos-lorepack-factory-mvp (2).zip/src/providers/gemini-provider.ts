import type { LorepackModel, Triplet } from '../types.ts';
import { embedBatchPinned, PINNED_MODEL, SUPPORTED_EMBEDDING_MODELS } from '../mint-gate.js';

const EMBEDDING_MODEL = PINNED_MODEL;
const FALLBACK_EMBEDDING_MODEL = 'gemini-embedding-001';
const GENERATION_MODEL = 'gemini-3.1-flash-lite';

export function generateDeterministicEmbedding(text: string, dimension = 768): number[] {
  const vec = new Float64Array(dimension);
  const clean = (text || '').toLowerCase().trim();
  if (!clean) {
    vec[0] = 1.0;
    return Array.from(vec);
  }

  const words = clean.split(/\s+/).filter(Boolean);

  const hashString = (str: string, seed = 0): number => {
    let h = 0x811c9dc5 ^ seed;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return Math.abs(h);
  };

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const weight = 1.0 / Math.sqrt(i + 1);
    for (let seed = 0; seed < 4; seed++) {
      const idx = hashString(word, seed) % dimension;
      const sign = hashString(word, seed + 10) % 2 === 0 ? 1 : -1;
      vec[idx] += weight * sign;
    }
  }

  const n = 3;
  for (let i = 0; i <= clean.length - n; i++) {
    const gram = clean.slice(i, i + n);
    const idx = hashString(gram, 13) % dimension;
    const sign = hashString(gram, 27) % 2 === 0 ? 1 : -1;
    vec[idx] += 0.5 * sign;
  }

  let sumSq = 0;
  for (let i = 0; i < dimension; i++) {
    sumSq += vec[i] * vec[i];
  }
  const norm = Math.sqrt(sumSq);
  if (norm > 0) {
    for (let i = 0; i < dimension; i++) {
      vec[i] = Number((vec[i] / norm).toFixed(6));
    }
  } else {
    vec[0] = 1.0;
  }

  return Array.from(vec);
}

export function extractHeuristicTriplets(text: string): Triplet[] {
  if (!text || typeof text !== 'string' || !text.trim()) return [];
  const clean = text.trim();
  const sentences = clean
    .split(/(?<=[.!?\n])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 5);

  const triplets: Triplet[] = [];
  const seen = new Set<string>();

  const commonRelations = [
    'established', 'created', 'founded', 'built', 'commanded', 'commands',
    'authored', 'secured', 'discovered', 'destroyed', 'allied with', 'allies with',
    'opposed', 'opposes', 'governs', 'governed', 'rules', 'ruled', 'protects',
    'protected', 'guards', 'guarded', 'maintains', 'maintained', 'controls',
    'controlled', 'serves', 'served', 'leads', 'led', 'contains', 'contained',
    'developed', 'develops', 'operates', 'operated', 'originates from', 'treaty with',
    'member of', 'connected to', 'derived from', 'part of', 'located in'
  ];

  for (const sentence of sentences) {
    const sClean = sentence.replace(/[.!?]+$/, '').trim();
    let matched = false;

    for (const rel of commonRelations) {
      const regex = new RegExp(`\\b([A-Z][a-zA-Z0-9_\\s-]{1,40}?)\\s+${rel}\\s+(?:a|an|the)?\\s*([A-Za-z0-9_\\s-]{2,50})`, 'i');
      const match = sClean.match(regex);
      if (match && match[1] && match[2]) {
        const s = match[1].trim();
        const r = rel.trim();
        const o = match[2].trim();
        const key = `${s.toLowerCase()}|${r.toLowerCase()}|${o.toLowerCase()}`;
        if (!seen.has(key) && s.length >= 2 && o.length >= 2) {
          seen.add(key);
          triplets.push({ s, r, o });
          matched = true;
          break;
        }
      }
    }

    if (!matched) {
      const words = sClean.split(/\s+/).filter(Boolean);
      const capWords = words.filter((w) => /^[A-Z][a-z0-9]/.test(w) && !['The', 'A', 'An', 'In', 'On', 'At', 'For', 'With'].includes(w));
      if (capWords.length >= 2) {
        const s = capWords[0];
        const o = capWords.slice(1).join(' ');
        const r = 'associated with';
        const key = `${s.toLowerCase()}|${r}|${o.toLowerCase()}`;
        if (!seen.has(key)) {
          seen.add(key);
          triplets.push({ s, r, o });
        }
      } else if (words.length >= 4) {
        const s = words.slice(0, 2).join(' ');
        const r = 'references';
        const o = words.slice(2, 6).join(' ');
        const key = `${s.toLowerCase()}|${r}|${o.toLowerCase()}`;
        if (!seen.has(key)) {
          seen.add(key);
          triplets.push({ s, r, o });
        }
      }
    }
  }

  return triplets;
}

function isQuotaOrRateLimitError(err: any): boolean {
  const msg = String(err?.message || err || '').toLowerCase();
  return (
    msg.includes('429') ||
    msg.includes('quota') ||
    msg.includes('503') ||
    msg.includes('high demand') ||
    msg.includes('resource_exhausted') ||
    msg.includes('resourceexhausted') ||
    msg.includes('exceeded your current quota') ||
    msg.includes('rate-limit') ||
    msg.includes('limit: 1000') ||
    msg.includes('limit: 3000')
  );
}

function cleanJsonFence(text: string): string {
  let clean = String(text || '').trim();
  if (clean.startsWith('```json')) {
    clean = clean.slice(7);
  } else if (clean.startsWith('```')) {
    clean = clean.slice(3);
  }
  if (clean.endsWith('```')) {
    clean = clean.slice(0, -3);
  }
  return clean.trim();
}

export class GeminiProvider implements LorepackModel {
  private apiKeys: string[] = [];
  private keyIndex = 0;

  setApiKeys(keys: string[]): void {
    this.apiKeys = (keys || [])
      .map((k) => String(k || '').trim())
      .filter(Boolean);
    this.keyIndex = 0;
  }

  getKey(): string {
    return this._getKey();
  }

  private _getKey(): string {
    if (this.apiKeys.length === 0) {
      throw new Error('API Keys Missing.');
    }
    const key = this.apiKeys[this.keyIndex];
    this.keyIndex = (this.keyIndex + 1) % this.apiKeys.length;
    return key;
  }

  private activeEmbeddingModel: string = PINNED_MODEL;
  private embeddingCache = new Map<string, number[]>();
  private tripletCache = new Map<string, Triplet[]>();
  private generationCache = new Map<string, { reply: string; timestamp: number }>();
  private quotaCooldownUntil = 0;

  setEmbeddingModel(model: string): void {
    if (model && typeof model === 'string' && model.trim()) {
      this.activeEmbeddingModel = model.trim();
    }
  }

  getEmbeddingModel(): string {
    return this.activeEmbeddingModel;
  }

  async getEmbeddings(text: string, keys?: string[], model?: string): Promise<number[] | null | undefined> {
    if (!text || !text.trim()) return null;
    const targetModel = model || this.activeEmbeddingModel || PINNED_MODEL;
    const cacheKey = `${targetModel}:${text.trim()}`;
    if (this.embeddingCache.has(cacheKey)) {
      return this.embeddingCache.get(cacheKey)!;
    }
    const res = await this.getEmbeddingsBatch([text], keys, model);
    return res[0] || null;
  }

  async getEmbeddingsBatch(texts: string[], keys?: string[], model?: string): Promise<number[][]> {
    if (!texts.length) return [];
    const targetModel = model || this.activeEmbeddingModel || PINNED_MODEL;

    // Check embedding cache first (de-duplication)
    const results: Array<number[] | null> = new Array(texts.length).fill(null);
    const missingIndices: number[] = [];
    const missingTexts: string[] = [];

    texts.forEach((text, i) => {
      const clean = (text || '').trim();
      const cacheKey = `${targetModel}:${clean}`;
      if (this.embeddingCache.has(cacheKey)) {
        results[i] = this.embeddingCache.get(cacheKey)!;
      } else {
        missingIndices.push(i);
        missingTexts.push(text);
      }
    });

    if (missingTexts.length === 0) {
      return results as number[][];
    }

    // Deduplicate among missing texts so identical strings in the same batch aren't sent multiple times
    const uniqueMissingMap = new Map<string, number[]>();
    missingTexts.forEach((text, idx) => {
      const clean = (text || '').trim();
      if (!uniqueMissingMap.has(clean)) {
        uniqueMissingMap.set(clean, [idx]);
      } else {
        uniqueMissingMap.get(clean)!.push(idx);
      }
    });

    const uniqueTexts = Array.from(uniqueMissingMap.keys());
    let freshEmbeddings: number[][] = [];

    try {
      const key = this._getKey();
      freshEmbeddings = await embedBatchPinned(
        fetch.bind(globalThis),
        key,
        uniqueTexts,
        uniqueTexts.map((_, i) => `batch:t${i + 1}`),
        targetModel
      );
    } catch (err: any) {
      if (isQuotaOrRateLimitError(err)) {
        this.quotaCooldownUntil = Date.now() + 20000;
        console.warn(`[GeminiProvider] Quota/Rate limit reached for embeddings. Cooldown active for 20s:`, err.message || err);
        throw err;
      }

      console.warn(`[GeminiProvider] Client-side batch embedding failed, attempting server proxy fallback...`, err.message || err);
      
      // Fallback to server proxy: process unique texts individually via /api/lorepack/embed
      try {
        freshEmbeddings = await Promise.all(
          uniqueTexts.map(async (t) => {
            const response = await fetch('/api/lorepack/embed', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ text: t, model: targetModel }),
            });
            if (!response.ok) {
              throw new Error(`Server embedding proxy failed: HTTP ${response.status}`);
            }
            const data = await response.json();
            if (!data.embedding) {
              throw new Error('Server embedding proxy returned empty payload');
            }
            return data.embedding;
          })
        );
      } catch (proxyErr: any) {
        console.error(`[GeminiProvider] Embedding proxy fallback failed:`, proxyErr.message || proxyErr);
        throw err; // Re-throw original error if fallback also fails
      }
    }

    // Save newly minted embeddings to cache and populate results
    uniqueTexts.forEach((text, uIdx) => {
      const emb = freshEmbeddings[uIdx];
      if (emb) {
        const cacheKey = `${targetModel}:${text}`;
        this.embeddingCache.set(cacheKey, emb);
        const originalMissingIndices = uniqueMissingMap.get(text) || [];
        originalMissingIndices.forEach((missingIdx) => {
          const overallIndex = missingIndices[missingIdx];
          results[overallIndex] = emb;
        });
      }
    });

    return results as number[][];
  }

  async extractTripletsFromText(text: string, modelName = GENERATION_MODEL): Promise<Triplet[]> {
    if (!text || !text.trim()) {
      return [];
    }

    const clean = text.trim();
    const cacheKey = `${modelName}:${clean}`;

    // 1. In-memory triplet cache (prevents duplicate API calls for repeated or identical content)
    if (this.tripletCache.has(cacheKey)) {
      return this.tripletCache.get(cacheKey)!;
    }

    // 2. Circuit-breaker: If currently in a quota cooldown window, instantly fall back to heuristic extraction
    if (Date.now() < this.quotaCooldownUntil) {
      const heuristics = extractHeuristicTriplets(clean);
      this.tripletCache.set(cacheKey, heuristics);
      return heuristics;
    }

    try {
      if (this.apiKeys.length > 0) {
        const key = this._getKey();
        try {
          const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
            modelName
          )}:generateContent?key=${encodeURIComponent(key)}`;

          const systemPrompt = `SYSTEM:
Extract explicit semantic relationships from the supplied lore.

OUTPUT:
Return ONLY a JSON array.

Each item must have exactly:
{
  "s": "Subject",
  "r": "Relation",
  "o": "Object"
}

If no defensible relationship exists, return [].`;

          const payload = {
            contents: [
              {
                parts: [
                  {
                    text: `${systemPrompt}\n\nLORE:\n${clean}`,
                  },
                ],
              },
            ],
            generationConfig: {
              responseMimeType: 'application/json',
              responseSchema: {
                type: 'ARRAY',
                items: {
                  type: 'OBJECT',
                  properties: {
                    s: { type: 'STRING' },
                    r: { type: 'STRING' },
                    o: { type: 'STRING' },
                  },
                  required: ['s', 'r', 'o'],
                },
              },
            },
          };

          const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });

          const json = await response.json();
          if (response.ok && !json.error) {
            const rawText =
              json.candidates?.[0]?.content?.parts
                ?.map((part: any) => part.text || '')
                .join('') || '[]';
            const cleanText = cleanJsonFence(rawText);
            const parsed = JSON.parse(cleanText);
            if (Array.isArray(parsed) && parsed.length > 0) {
              this.tripletCache.set(cacheKey, parsed);
              return parsed;
            }
          }

          // If quota or rate-limit error, trip circuit breaker and avoid hammering further endpoints
          if (response.status === 429 || json.error?.code === 429 || isQuotaOrRateLimitError(json.error)) {
            this.quotaCooldownUntil = Date.now() + 20000;
            console.warn('[GeminiProvider] Quota reached during triplet extraction. Cooldown engaged for 20s.');
            const heuristics = extractHeuristicTriplets(clean);
            this.tripletCache.set(cacheKey, heuristics);
            return heuristics;
          }
        } catch (err: any) {
          if (isQuotaOrRateLimitError(err)) {
            this.quotaCooldownUntil = Date.now() + 20000;
            console.warn('[GeminiProvider] Quota/Rate limit exception during extraction. Cooldown engaged for 20s.');
            const heuristics = extractHeuristicTriplets(clean);
            this.tripletCache.set(cacheKey, heuristics);
            return heuristics;
          }
        }
      }

      // Fallback to server proxy only if cooldown is not active
      if (Date.now() >= this.quotaCooldownUntil) {
        try {
          const response = await fetch('/api/lorepack/triplets', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: clean, model: modelName }),
          });

          if (response.ok) {
            const data = await response.json();
            if (Array.isArray(data.triplets) && data.triplets.length > 0) {
              this.tripletCache.set(cacheKey, data.triplets);
              return data.triplets;
            }
          } else if (response.status === 429) {
            this.quotaCooldownUntil = Date.now() + 20000;
          }
        } catch (proxyErr) {
          console.warn('[GeminiProvider] Server proxy triplet extraction failed, falling back to heuristics:', proxyErr);
        }
      }

      // Final zero-crash fallback: Heuristic rule-based triplet extraction
      const heuristics = extractHeuristicTriplets(clean);
      this.tripletCache.set(cacheKey, heuristics);
      return heuristics;
    } catch (error) {
      console.warn('[GeminiProvider] Triplet extraction error, falling back to deterministic heuristics:', error);
      const heuristics = extractHeuristicTriplets(clean);
      this.tripletCache.set(cacheKey, heuristics);
      return heuristics;
    }
  }

  async generateText(
    prompt: string,
    systemPrompt?: string,
    modelName = GENERATION_MODEL
  ): Promise<string> {
    const cleanPrompt = (prompt || '').trim();
    const cacheKey = `${modelName}:${systemPrompt || ''}:${cleanPrompt}`;

    // 1. Check generation cache (60s TTL) to prevent duplicate identical calls eating credits
    const cached = this.generationCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < 60000) {
      return cached.reply;
    }

    // 2. Circuit-breaker: If currently in a quota cooldown window, return graceful synthesis
    if (Date.now() < this.quotaCooldownUntil) {
      return `[SYSTEM LOCUS]: Active generation paused due to rate-limit protection. Memory locus operational.`;
    }

    try {
      if (this.apiKeys.length > 0) {
        const key = this._getKey();
        try {
          const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
            modelName
          )}:generateContent?key=${encodeURIComponent(key)}`;

          const payload: any = {
            contents: [{ parts: [{ text: cleanPrompt }] }],
          };
          if (systemPrompt) {
            payload.systemInstruction = { parts: [{ text: systemPrompt }] };
          }

          const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });

          const json = await response.json();
          if (response.ok && !json.error) {
            const textOut = json.candidates?.[0]?.content?.parts
              ?.map((part: any) => part.text || '')
              .join('');
            if (textOut) {
              this.generationCache.set(cacheKey, { reply: textOut, timestamp: Date.now() });
              return textOut;
            }
          }

          // If quota exceeded, trip circuit breaker and do NOT loop through candidate fallbacks
          if (response.status === 429 || json.error?.code === 429 || isQuotaOrRateLimitError(json.error)) {
            this.quotaCooldownUntil = Date.now() + 20000;
            console.warn('[GeminiProvider] Quota reached during text generation. Cooldown engaged for 20s.');
            return `[SYSTEM LOCUS]: Quota rate-limit reached. Rate shield active. Memory locus operational.`;
          }
        } catch (mErr: any) {
          if (isQuotaOrRateLimitError(mErr)) {
            this.quotaCooldownUntil = Date.now() + 20000;
            return `[SYSTEM LOCUS]: Quota rate-limit reached. Rate shield active. Memory locus operational.`;
          }
        }
      }

      // Fallback to server proxy only if cooldown is not active
      if (Date.now() >= this.quotaCooldownUntil) {
        try {
          const response = await fetch('/api/lorepack/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: cleanPrompt, systemPrompt, model: modelName }),
          });

          if (response.ok) {
            const data = await response.json();
            if (data && typeof data.text === 'string') {
              this.generationCache.set(cacheKey, { reply: data.text, timestamp: Date.now() });
              return data.text;
            }
          } else if (response.status === 429) {
            this.quotaCooldownUntil = Date.now() + 20000;
          }
        } catch (proxyErr) {
          console.warn('[GeminiProvider] Server proxy generation error:', proxyErr);
        }
      }

      return `[SYSTEM LOCUS]: Query processed against active memory records. Locus operational.`;
    } catch (error) {
      console.warn('[GeminiProvider] Content generation error, returning graceful locus message:', error);
      return `[SYSTEM LOCUS]: Query acknowledged. Locus operational.`;
    }
  }

  async fetchModels(): Promise<string[]> {
    try {
      if (this.apiKeys.length > 0) {
        try {
          const key = this._getKey();
          const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(key)}`;
          const response = await fetch(url);
          
          if (response.ok) {
            const data = await response.json();
            const models = data.models || [];
            const generateModels = models
              .map((m: any) => (m.name || '').replace('models/', ''))
              .filter((name: string) => {
                const lower = name.toLowerCase();
                // Allow all models except embedding, audio, vision, and imagen
                return !lower.includes('embedding') &&
                  !lower.includes('audio') &&
                  !lower.includes('vision') &&
                  !lower.includes('imagen');
              });

            if (generateModels.length > 0) {
              return generateModels;
            }
          }
        } catch (clientErr) {
          console.warn('[GeminiProvider] Client-side fetch models failed, falling back to server proxy:', clientErr);
        }
      }
      
      // Fallback to server proxy
      try {
        const response = await fetch('/api/lorepack/models');
        if (response.ok) {
          const data = await response.json();
          if (data.models && data.models.length > 0) {
            return data.models;
          }
        }
      } catch (proxyErr) {
        console.warn('[GeminiProvider] Server proxy model fetch failed, using default fallback list:', proxyErr);
      }

      return [
        'gemini-3.6-flash',
        'gemini-3.1-flash-lite',
        'gemini-3.1-pro-preview',
        'gemini-2.5-pro',
        'gemma-3-27b-it',
        'gemma-3-12b-it',
        'gemma-2-27b-it',
        'gemma-2-9b-it',
        'text-bison-001'
      ];
    } catch (error) {
      console.error('[GeminiProvider] Fetch models error:', error);
      return [
        'gemini-3.6-flash',
        'gemini-3.1-flash-lite',
        'gemini-3.1-pro-preview',
        'gemini-2.5-pro',
        'gemma-3-27b-it',
        'gemma-3-12b-it',
        'gemma-2-27b-it',
        'gemma-2-9b-it',
        'text-bison-001'
      ];
    }
  }

  async fetchEmbeddingModels(): Promise<string[]> {
    const fallbackList = Array.from(SUPPORTED_EMBEDDING_MODELS);
    try {
      if (this.apiKeys.length > 0) {
        try {
          const key = this._getKey();
          const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(key)}`;
          const response = await fetch(url);
          if (response.ok) {
            const data = await response.json();
            const models = data.models || [];
            const embeddingModels = models
              .map((m: any) => (m.name || '').replace('models/', ''))
              .filter((name: string) => {
                const lower = name.toLowerCase();
                return lower.includes('embedding') || lower.includes('embed');
              });

            if (embeddingModels.length > 0) {
              // Ensure default gemini-embedding-2 is first
              const combined = Array.from(new Set(['gemini-embedding-2', ...embeddingModels, ...fallbackList]));
              return combined;
            }
          }
        } catch (clientErr) {
          console.warn('[GeminiProvider] Client-side fetch embedding models failed, attempting server proxy:', clientErr);
        }
      }

      // Fallback to server proxy
      try {
        const response = await fetch('/api/lorepack/embedding-models');
        if (response.ok) {
          const data = await response.json();
          if (Array.isArray(data.models) && data.models.length > 0) {
            return Array.from(new Set(['gemini-embedding-2', ...data.models, ...fallbackList]));
          }
        }
      } catch (proxyErr) {
        console.warn('[GeminiProvider] Server proxy embedding models fetch error:', proxyErr);
      }

      return fallbackList;
    } catch (error) {
      console.error('[GeminiProvider] Fetch embedding models error:', error);
      return fallbackList;
    }
  }
}
